// Routes this Chrome profile through the chosen vpnctl session's SOCKS5 proxy.
// sessions.json is written by vpnctl whenever sessions are added or removed.

async function loadSessions() {
  const res = await fetch(chrome.runtime.getURL('sessions.json'), { cache: 'no-store' });
  return (await res.json()).sessions || {};
}

// A session is up when its container's HTTP proxy port answers at all.
async function isUp(session) {
  try {
    await fetch(`http://127.0.0.1:${session.http_port}/`, {
      cache: 'no-store',
      signal: AbortSignal.timeout(2000),
    });
    return true;
  } catch {
    return false;
  }
}

async function showBadge(name, reachable) {
  let text = '';
  let title = 'VPN: off';
  if (name) {
    text = reachable ? name.slice(0, 4).toUpperCase() : '!';
    title = reachable ? `VPN: ${name}` : `VPN: ${name} is not connected. Run: vpnctl up ${name}`;
  }
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color: reachable ? '#1a73e8' : '#d93025' });
  await chrome.action.setTitle({ title });
}

async function apply(name) {
  const sessions = await loadSessions();
  const session = name ? sessions[name] : null;
  if (!session) {
    name = null;
    await chrome.proxy.settings.clear({ scope: 'regular' });
  } else {
    await chrome.proxy.settings.set({
      scope: 'regular',
      value: {
        mode: 'fixed_servers',
        rules: {
          // socks5 makes Chrome send hostnames to the proxy, so company DNS names resolve inside the VPN.
          singleProxy: { scheme: 'socks5', host: '127.0.0.1', port: session.socks_port },
          bypassList: ['localhost', '127.0.0.1', '[::1]'],
        },
      },
    });
  }
  await chrome.storage.local.set({ session: name });
  await showBadge(name, session ? await isUp(session) : true);
  return name;
}

async function refreshBadge() {
  const { session: name } = await chrome.storage.local.get('session');
  if (!name) return showBadge(null, true);
  const session = (await loadSessions())[name];
  if (!session) return apply(null); // removed from vpnctl
  await showBadge(name, await isUp(session));
}

async function restore() {
  const { session } = await chrome.storage.local.get('session');
  await apply(session || null);
  await chrome.alarms.create('status', { periodInMinutes: 1 });
}

chrome.runtime.onInstalled.addListener(restore);
chrome.runtime.onStartup.addListener(restore);
chrome.alarms.onAlarm.addListener(refreshBadge);
chrome.proxy.onProxyError.addListener(refreshBadge);

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg.type === 'select') {
    apply(msg.name).then((name) => reply({ session: name }));
    return true; // reply asynchronously
  }
  if (msg.type === 'status') {
    loadSessions()
      .then((sessions) => Promise.all(Object.entries(sessions).map(async ([n, s]) => [n, await isUp(s)])))
      .then((entries) => reply(Object.fromEntries(entries)));
    return true;
  }
});
