const list = document.getElementById('list');
const hint = document.getElementById('hint');

const { sessions = {} } = await (await fetch('sessions.json', { cache: 'no-store' })).json();
let { session: current = null } = await chrome.storage.local.get('session');
let status = {};

function row(name, title, sub) {
  const btn = document.createElement('button');
  btn.className = 'row';
  btn.setAttribute('aria-pressed', String(current === name));
  btn.innerHTML = '<span class="radio"></span><span class="text"><div class="name"></div><div class="sub"></div></span><span class="status"></span>';
  btn.querySelector('.name').textContent = title;
  btn.querySelector('.sub').textContent = sub;
  btn.querySelector('.sub').title = sub;
  const st = btn.querySelector('.status');
  if (name && name in status) {
    st.textContent = status[name] ? 'connected' : 'not connected';
    st.classList.toggle('up', status[name]);
  } else {
    st.remove();
  }
  btn.addEventListener('click', async () => {
    const res = await chrome.runtime.sendMessage({ type: 'select', name });
    current = res.session;
    render();
  });
  return btn;
}

function render() {
  list.replaceChildren(
    row(null, 'Off', 'Normal internet'),
    ...Object.entries(sessions).map(([name, s]) => row(name, name, s.target)),
  );
  if (!Object.keys(sessions).length) {
    setHint('No sessions yet. Add one in Terminal with ', 'vpnctl add', '.');
  } else if (current && status[current] === false) {
    setHint(`${current} is not connected, so pages won't load. In Terminal run `, `vpnctl up ${current}`, ', or choose Off.');
  } else {
    setHint('Only this Chrome profile is affected. Other apps use your normal internet.');
  }
}

function setHint(before, command, after = '') {
  const parts = [before];
  if (command) {
    const code = document.createElement('code');
    code.textContent = command;
    parts.push(code, after);
  }
  hint.replaceChildren(...parts);
}

render();
status = await chrome.runtime.sendMessage({ type: 'status' });
render();
