#!/bin/sh
# Apply DNS servers pushed by the OpenVPN server (dhcp-option DNS/DOMAIN) to the container.
[ "$script_type" = "up" ] || exit 0
dns=""; search=""
for opt in $(env | grep '^foreign_option_' | sort | cut -d= -f2- | tr ' ' '|'); do
  case "$opt" in
    dhcp-option\|DNS\|*)    dns="$dns ${opt##*|}" ;;
    dhcp-option\|DOMAIN\|*) search="$search ${opt##*|}" ;;
  esac
done
[ -n "$dns" ] || exit 0
cp /etc/resolv.conf /etc/resolv.conf.orig 2>/dev/null || true
{ [ -n "$search" ] && echo "search$search"; for d in $dns; do echo "nameserver $d"; done; } > /etc/resolv.conf
