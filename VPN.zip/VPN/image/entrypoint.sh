#!/bin/sh
# Session container: start the VPN client, then expose SOCKS5 (1080) and HTTP (8888) proxies.
set -e
TYPE="$1"

# MaxClients: browsers keep many idle connections open; tinyproxy's default of 100 makes
# new connections queue for seconds once the whole Mac uses the session as its system proxy.
cat > /etc/tinyproxy.conf <<CONF
Port 8888
Listen 0.0.0.0
User nobody
Group nogroup
Timeout 600
MaxClients 4000
Allow 0.0.0.0/0
DisableViaHeader Yes
# The Chrome extension checks each VPN by fetching http://127.0.0.1:<port>/ - answer that here.
StatHost "127.0.0.1"
LogLevel Warning
CONF
microsocks -i 0.0.0.0 -p 1080 &
tinyproxy -d -c /etc/tinyproxy.conf &

case "$TYPE" in
  fortinet)
    keepalive.sh &
    exec openfortivpn -c /etc/vpn/config --set-dns=1
    ;;
  openvpn)
    cd /etc/vpn/openvpn
    # Drop privilege-dropping directives; group names differ between distros.
    sed -i -E '/^\s*(user|group)\s/d' config.ovpn
    set -- --config config.ovpn --script-security 2 \
           --up /usr/local/bin/openvpn-dns.sh --down /usr/local/bin/openvpn-dns.sh
    [ -f /etc/vpn/auth ] && set -- "$@" --auth-user-pass /etc/vpn/auth --auth-nocache
    exec openvpn "$@"
    ;;
  *)
    echo "unknown session type: $TYPE" >&2; exit 2
    ;;
esac
