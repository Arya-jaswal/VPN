#!/bin/sh
# Keep the tunnel from going idle. Idle VPN connections get dropped by NAT routers, mobile networks
# and the gateway's idle timer, so every 30 seconds send one small DNS query to the VPN's own DNS
# server (over TCP) and one ping to the tunnel's far end. (A few hundred bytes a minute.)
while sleep 30; do
  ip link show ppp0 >/dev/null 2>&1 || continue
  ns=$(awk '/^nameserver/ {print $2; exit}' /etc/resolv.conf)
  [ -n "$ns" ] && dig +tcp +time=5 +tries=1 +short @"$ns" . SOA >/dev/null 2>&1
  peer=$(ip -4 -o addr show ppp0 | sed -n 's/.* peer \([0-9.]*\).*/\1/p')
  [ -n "$peer" ] && ping -c 1 -W 3 "$peer" >/dev/null 2>&1
done
