# vpnctl

Run several office VPNs at the same time and switch between them.

Each VPN runs in its own Docker container and shows up on your Mac as a local proxy
(SOCKS5 + HTTP). All sessions stay connected; you choose which one each app uses.

```
          ┌── vpnctl-clientA  (openfortivpn) ── SOCKS 127.0.0.1:1081 / HTTP :8081
Mac ──────┼── vpnctl-clientB  (openfortivpn) ── SOCKS 127.0.0.1:1082 / HTTP :8082
          └── vpnctl-prod     (openvpn)      ── SOCKS 127.0.0.1:1083 / HTTP :8083
```

Requires Docker Desktop. The image builds automatically the first time you connect.

## Setup

```sh
# Run these from inside the VPN folder (the one that contains vpnctl).
# -f replaces an old or broken link left by an earlier attempt.
chmod +x vpnctl
sudo mkdir -p /usr/local/bin
sudo ln -sf "$PWD/vpnctl" /usr/local/bin/vpnctl

# Fortinet with Duo (asks for a password and offers to save it in Keychain)
vpnctl add clientA --type fortinet --host vpn.clienta.com:10443 --user aryan --duo auto

# OpenVPN / Tunnelblick profile
vpnctl add prod --type openvpn --ovpn ~/Library/Application\ Support/Tunnelblick/Configurations/AryanJaswal-PROD.tblk
```

Duo modes:
- `auto`: the server sends a push on its own. Approve it on your phone.
- `push`: sends the word "push" as the second factor.
- `passcode`: asks you for a Duo code each time you connect.

## VPN addresses

```sh
vpnctl url                                              # show every session's gateway
vpnctl url sila https://iaccess.vortex.cloud/prth-sila  # change one
vpnctl add newclient --type fortinet --host https://vpn.newclient.com/realm --user aryan.a --duo auto   # add another VPN
```

`--host` and `vpnctl url` accept the address the way FortiClient shows it (`https://host:port/realm`),
a browser login link (`https://host/remote/login?realm=x`), or just `host` / `host:port`.
The last part of a FortiClient address is the realm; leave it off if the VPN has none.
A change applies the next time that session connects.

Safety checks: a link copied from an email that Outlook Safe Links or Google wrapped is unwrapped to the
real address (other wrapped links are refused). An address that can't be looked up is not saved; add
`--force` if you're offline and sure it's right.

## Daily use

```sh
vpnctl up clientA prod        # connect both (keep running side by side)
vpnctl ls                     # status, tunnel IPs, ports

vpnctl browser clientA https://intranet.clienta.com   # Chrome window with its own profile, via clientA
vpnctl shell prod             # terminal where everything you start (python, aws, curl, DB drivers) uses prod
vpnctl ssh clientA user@10.1.2.3                      # ssh via clientA with your normal ~/.ssh
vpnctl run prod -- curl http://10.0.0.5/health        # one command via prod

vpnctl use clientA            # macOS system proxy -> clientA (Safari, Chrome default profile, most apps)
vpnctl use prod               # switch the system proxy to prod
vpnctl use off                # back to direct

vpnctl logs clientA -f        # troubleshooting
vpnctl down clientA           # or: vpnctl down --all
```

## Databases (DBeaver, MySQL Workbench, scripts)

Database apps can't use a proxy, so vpnctl gives each database a fixed local address that leads
through a VPN. In the app, connect to host `127.0.0.1` and the forward's port. Forwards work whenever
their VPN is connected, and different databases can use different VPNs at the same time.

```sh
vpnctl forward                                  # list: local address -> database, and through which VPN
vpnctl forward test                             # check every database answers
vpnctl forward add reports cpx db.internal:3306 # add one (picks a free local port, e.g. 13306)
vpnctl forward via reports plastiq              # send it through another VPN
vpnctl forward rm reports
```

For the `mysql` command line, use `-h 127.0.0.1` (not `localhost`, which makes it look for a local server).
Scripts and terminal tools can also just run inside `vpnctl shell <vpn>`, which routes their database
connections too (see below).

## Use a VPN in your normal Chrome

The `chrome-extension/` folder is a small extension that switches your everyday Chrome profile
(same bookmarks, logins and tabs) between sessions. Other apps and other Chrome profiles are not affected.

One-time setup (or run `vpnctl chrome` to see these steps):

1. Open `chrome://extensions` and turn on **Developer mode** (top right).
2. Click **Load unpacked** and choose `/Users/aryan/VPN/chrome-extension`.
   (In the file picker, Cmd+Shift+G lets you paste the path.)
3. Pin **VPN Switch (vpnctl)** from the puzzle-piece menu.

Click the shield icon and pick **Off**, **cpx**, **plastiq** or **sila**. The badge shows the session
Chrome is using; a red **!** means that session isn't connected (`vpnctl up <name>`). Sessions added
with `vpnctl add` appear in the list automatically.

## Terminal: `vpnctl shell`

`vpnctl shell sila` opens a shell (prompt starts with `[sila]`) where the programs you start send
**all** their connections through Sila: Python and its database drivers, `aws`, `pip`, curl, git, etc.
Run your usual commands after it, e.g.:

```sh
vpnctl shell sila
aws sso login --profile my-profile
cd ~/grandcentral && source venv/bin/activate
export AWS_PROFILE=my-profile AWS_DEFAULT_REGION=us-east-1
python manage.py shell
```

This uses proxychains-ng (`brew install proxychains-ng`). Apple's own programs and scripts started
through `/usr/bin/env` (e.g. `./manage.py`) only get the web-proxy settings, so start Python as
`python manage.py ...`.

## Staying connected

**The main cause of dropped VPNs is this Mac going to sleep.** A sleeping Mac can't hold a connection
open, so every tunnel dies with it, and getting back in means a fresh login and another Duo push. On
battery this Mac is set to sleep about two minutes after you look away (`pmset -g custom`), which is why
VPNs seemed to drop "every half hour" — that was just how long you happened to be at the keyboard.

So while any VPN is connected, vpnctl holds macOS's *idle sleep* back. The screen still turns off and the
battery still rests; only suspending is prevented, and only while a VPN is up.

```sh
vpnctl awake        # show whether this is on
vpnctl awake off    # let the Mac sleep as usual (VPNs will drop when it does)
vpnctl awake on     # back on
```

Closing the lid still sleeps the Mac whatever this is set to. When that happens — or when the Wi-Fi
drops, or the server really does log you out — auto-reconnect takes over.

A VPN you connect with `vpnctl up` reconnects by itself whenever it drops, until you `vpnctl down` it.
Each reconnect is a new login:

- A notification says which VPN is reconnecting, then its Duo push arrives. Approve it, and the VPN
  is back a few seconds later. If two VPNs dropped, they reconnect one after the other.
- It only reconnects while you're at the Mac (screen unlocked, keyboard or mouse used in the last
  5 minutes) and the server can be reached. If you're away or offline, it waits until you're back.
- If two reconnects in a row aren't approved, it stops and tells you. Run `vpnctl up <name>` when
  you're ready. VPNs that need a typed Duo passcode just get a notification.
- `vpnctl ls` shows what's happening (`reconnecting`, `waiting for internet`, `reconnects when you're back`).
  The background log is `~/.vpnctl/watcher.log`.

Notifications show as coming from **Script Editor**. If you don't see them, turn them on in
System Settings → Notifications → Script Editor.

Each VPN also sends a tiny keep-alive (a DNS lookup and a ping every 30 s), so idle tunnels aren't
cut off by the server. `vpnctl logs <name> --previous` shows how the last connection ended; if a drop
lines up with a sleep in `pmset -g log`, the Mac slept rather than the VPN failing.

## Notes

- If a Fortinet gateway uses a self-signed certificate, the first `up` fails and shows its
  fingerprint. Choose to trust it, then run `up` again.
- Changed your password or username? `vpnctl credentials` updates every session at once
  (or `vpnctl credentials sila` for just one). Press Enter at a prompt to keep the current value.
- Apps that ignore proxies (some native clients, raw TCP/UDP tools) can be run inside the
  tunnel: `vpnctl exec <name> -- <command>`. The container includes ssh, curl, dig, nc and ping.
- Config is in `~/.vpnctl/`. Passwords live in the macOS Keychain (service `vpnctl`), and are copied
  straight into the container at connect time, never written to disk.
